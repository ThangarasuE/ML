//2.Connect your application to MongoDB Cloud Instance?

const express = require('express');
const app = express();
const port=3300

const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/', 
    { useNewUrlParser: true, 
    useUnifiedTopology: true })

    .then(() => {
        console.log(`CONNECTED TO MONGODB!`);
    })
    .catch((err) => {
        console.log(`OH NO! MONGO CONNECTION ERROR!`);
        console.log(err);
    })

    app.listen(port,()=>{
        console.log("contected to port"+port);
        console.log('mongoDB connected global instance');
    })