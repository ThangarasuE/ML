//1.Connect your application to MongoDB local instance?

const express = require('express');
const app = express();
const port=3300;

const MongoClient = require('mongodb').MongoClient;

MongoClient.connect("mongodb://localhost:27017/myRandomDB", (err, client)=> {
     if(err) throw err;   
             
});
app.listen(port, () => {
    console.log('Connected to PORT'+port);
    console.log('mongoDB connected to local instance...');
})